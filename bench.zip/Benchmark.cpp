#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdint.h>
#include <assert.h>
#include <time.h>
#include <sys/time.h>

#define CUDA 0

#define NUM_THREADS_PER_BLK 128

void barf(const char *fmt, ...)
{
    va_list args;

    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);

    exit(1);
}

unsigned long utime(void)
{
    struct timeval tv;
    unsigned long result = 0;

    gettimeofday(&tv, NULL);
    result += (tv.tv_sec * 1000000);
    result += tv.tv_usec;

    return result;
}


int getIndex(int rows, int cols, int row, int col) {
    return row * cols + col;
}


void allocMatrix(float *ptr, int rows, int cols) {
    for(int i = 0; i < cols*rows; i++) {
        ptr[i] = (float)drand48();
    }
}

void printMatrix(float *matrix, int rows, int cols) {
    printf("[");
    for(int i=0; i < rows; i++) {
        for(int j = 0; j < cols; j++){
            if(j == (cols-1) && i == (rows-1)) {
                printf("%0.4f ]\n", matrix[getIndex(rows, cols, i, j)]);
                return;
            }
            printf("%0.4f ", matrix[getIndex(rows, cols, i, j)]);

        }
        printf("\n ");
    }
}

int main(int argc, char **argv)
{
    srand48(time(0));

    int rows_a = 4;
    int cols_a = 8;

    int rows_b = cols_a;
    int cols_b = 4;

    float *matrix_a = (float*)malloc(rows_a*cols_a*sizeof(float));
    float *matrix_b = (float*)malloc(rows_b*cols_b*sizeof(float));
    float *matrix_res = (float*)malloc(rows_a*cols_b*sizeof(float));

    allocMatrix(matrix_a, rows_a, cols_a);
    allocMatrix(matrix_b, rows_b, cols_b);

    printMatrix(matrix_a, rows_a, cols_a);
    printf("\n");
    printMatrix(matrix_b, rows_b, cols_b);
    printf("\n");


    unsigned long begin = utime();

    int res_index, a_index, b_index;
    for(int i=0; i < rows_a; i++){
        for(int j=0; j < cols_b; j++){
            res_index = getIndex(rows_a, cols_b, i, j);
            matrix_res[res_index] = 0;
            for(int k=0; k < rows_b; k++){
                a_index = getIndex(rows_a,cols_a, i, k);
                b_index = getIndex(rows_b, cols_b, k, j);
                matrix_res[res_index] += matrix_a[a_index] * matrix_b[b_index];
            }
        }
    }
    printMatrix(matrix_res, rows_a, cols_b);


    unsigned long end = utime();

    unsigned long elapsed = end - begin;
    printf("computation took %lu microseconds\n", elapsed);

    free(matrix_a);
    free(matrix_b);
    free(matrix_res);
    return 0;
}

// vim:syntax=c
